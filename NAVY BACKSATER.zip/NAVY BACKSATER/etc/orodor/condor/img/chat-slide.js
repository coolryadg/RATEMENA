$(function () {
    $("#slidebox").fadeIn(500).animate({
        marginLeft: "0"
    }, 2000);
	$(".close").click(function () {
    $("#slidebox").fadeIn(500).animate({
		marginLeft: "-430"
	}, 2000);
});
});
